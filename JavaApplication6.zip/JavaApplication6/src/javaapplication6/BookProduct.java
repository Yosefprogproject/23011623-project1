package javaapplication6;

public class BookProduct extends Product{
    private String author;
    private String publisher;
    
    public BookProduct(){
        
    }
    public BookProduct(int productid,String name,double price,String author,String publisher){
        super(productid,name,price);
        this.author=author;
        this.publisher=publisher;
    }
    
    public void setauthor(String author){
        this.author=author;
    }
    public String getauthor(){
        return author;
    }
    public void setpublisher(String publisher){
        this.publisher=publisher;
    }
    public String getpublisher(){
        return publisher;
    }
}