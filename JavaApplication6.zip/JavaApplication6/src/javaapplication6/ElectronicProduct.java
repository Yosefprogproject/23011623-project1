package javaapplication6;

public class ElectronicProduct extends Product{
    private String brand;
    private int warrantyPeriod;
    
    public ElectronicProduct(){
        
    }
    public ElectronicProduct(int productid,String name,double price,String brand,int warrantyPeriod){
        super(productid,name,price);
        this.brand=brand;
        this.warrantyPeriod=Math.abs(warrantyPeriod);
    }
    
    public void setbrand(String brand){
        this.brand=brand;
    }
    public String getbrand(){
        return brand;
    }
    public void setwarrantyPeriod(int warrantyPeriod){
        this.warrantyPeriod=Math.abs(warrantyPeriod);
    }
    public int getwarrantyPeriod(){
        return warrantyPeriod;
    }
}