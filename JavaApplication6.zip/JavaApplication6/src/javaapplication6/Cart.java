package javaapplication6;

public class Cart {
    int customerId;
    int nProducts;
    Product products[];
    
    public Cart(){
        
    }
    public Cart(int customerId, int nProducts){
        this.customerId=Math.abs(customerId);
        this.nProducts=Math.abs(nProducts);
    }
    public void setcustomerId(int customerId){
        this.customerId=Math.abs(customerId);
    }
    public int getcustomerId(){
        return customerId;
    }
    public void setnproducts(int nProducts){
        this.nProducts=Math.abs(nProducts);
        products=new Product[nProducts];
    }
    public int getnproducts(){
        return nProducts;
    }
    
    public void addProducts(Product product,int index){
        if(index>=0 && index<nProducts){
            products[index]=product;
        }
    }

    public void removeProduct(int empty){
        products[empty]=null;
    }
    
    public double calculatePrice(){
        double sum=0;
        for(int i=0;i<nProducts;i++){
            Product p=products[i];
            if(p!=null){
                sum+=p.getprice();
            }
        }
        return sum;
    }
    
    public boolean placeOrder(int choise){
        boolean option =true;
        if(choise==1){
            option=true;
        }else if(choise==2){
            option=false;
        }
        return option;
    }
}