package javaapplication6;

public class Order {
    int customerId;
    int nProducts;
    int orderId;
    Product products[]=new Product[nProducts];
    double totalprice;
    
    public Order(){
        
    }
    public Order(int customerId,int nProducts,int orderId,double totalprice,Product[] products){
        this.customerId=Math.abs(customerId);
        this.nProducts=Math.abs(nProducts);
        this.orderId=Math.abs(orderId);
        this.totalprice=Math.abs(totalprice);
        this.products=products;
    }
    
    public void printOrderInfo(){
        System.out.println("Here's your order's summary:");
        System.out.println("Order ID: "+orderId);
        System.out.println("Customer ID: "+customerId);
        System.out.println("Products:");
        for(int i=0;i<nProducts;i++){
            Product p=products[i];
            System.out.println(p.getname()+" - $"+p.getprice());
        }
        System.out.println("Total Price: $"+totalprice);
    }
}