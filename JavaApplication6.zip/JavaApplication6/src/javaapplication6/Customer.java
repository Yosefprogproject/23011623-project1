package javaapplication6;

public class Customer {
    int customerId;
    private String customername;
    private String address;
    
    public Customer(){
        
    }
    public Customer(int customerId,String customername,String address){
        this.customerId=Math.abs(customerId);
        this.customername=customername;
        this.address=address;
    }
    
    public void setcustomerId(int customerId){
        this.customerId=Math.abs(customerId);
    }
    public int getcustomerId(){
        return customerId;
    }
    public void setcustomername(String customername){
        this.customername=customername;
    }
    public String getcustomername(){
        return customername;
    }
    public void setaddress(String address){
        this.address=address;
    }
    public String getaddress(){
        return address;
    }
}