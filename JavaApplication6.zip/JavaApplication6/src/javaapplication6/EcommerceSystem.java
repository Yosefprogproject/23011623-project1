package javaapplication6;
import java.util.Scanner;
public class EcommerceSystem {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        
        ElectronicProduct E1=new ElectronicProduct(1,"SmartPhone",599.99,"Samsung",1);
        ClothingProduct C1=new ClothingProduct(2,"T-Shirt",19.99,"Medium","Cotton");
        BookProduct B1=new BookProduct(3,"OOP",39.99,"O'Reilly","X Publications");
        
        System.out.println("Welcome to the E-Commerce System!");
        
        System.out.println("Please enter your id:");
        int id=Integer.parseInt(input.nextLine());
        System.out.println("Please enter your name:");
        String name=input.nextLine();
        System.out.println("Please enter your address:");
        String address=input.nextLine();
        
        Customer Cust1=new Customer(id,name,address);
        
        System.out.println("How many products you want in your cart?");
        int num=input.nextInt();
        
        Cart Ca1=new Cart(id,num);
        Ca1.setnproducts(num);
        for(int i=0;i<num;i++){
            System.out.println("Which product would you like to add? 1-SmartPhone 2-T-Shirt 3-OOP");
            int choice=input.nextInt();
            switch(choice){
                case 1:
                    Ca1.addProducts(E1,i);
                    break;
                case 2:
                    Ca1.addProducts(C1,i);
                    break;
                case 3:
                    Ca1.addProducts(B1,i);
                    break;
                default:
                    break;
            }
        }
        
        int x=1;
        Order O =new Order(id,num,x,(double)Ca1.calculatePrice(),Ca1.products);
        System.out.println("Your Total is $"+Ca1.calculatePrice()+" .Would you like to place the order? 1-Yes 2-No");
        int YN=input.nextInt();
        
        if(Ca1.placeOrder(YN)==true){
            O.printOrderInfo();
            x++;
        }
    }
}