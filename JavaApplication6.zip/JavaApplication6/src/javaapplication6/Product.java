package javaapplication6;

public class Product {
    int productid;
    String name;
    double price;
    
    public Product(){
        
    }
    public Product(int productid,String name,double price){
        this.productid=Math.abs(productid);
        this.name=name;
        this.price=Math.abs(price);
    }
    
    public void setproductid(int productid){
        this.productid=Math.abs(productid);
    }
    public int getproductid(){
        return productid;
    }
    public void setname(String name){
        this.name=name;
    }
    public String getname(){
        return name;
    }
    public void setprice(double price){
        this.price=Math.abs(price);
    }
    public double getprice(){
        return price;
    }
}