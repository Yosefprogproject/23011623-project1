package javaapplication6;

public class ClothingProduct extends Product{
    private String size;
    private String fabric;
    
    public ClothingProduct(){
        
    }
    public ClothingProduct(int productid,String name,double price,String size,String fabric){
        super(productid,name,price);
        this.size=size;
        this.fabric=fabric;
    }
    
    public void setsize(String size){
        this.size=size;
    }
    public String getsize(){
        return size;
    }
    public void setfabric(String fabric){
        this.fabric=fabric;
    }
    public String getfabric(){
        return fabric;
    }
}